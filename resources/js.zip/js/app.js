import "bootstrap-icons/font/bootstrap-icons.css";
import { createPopper } from '@popperjs/core';
import './bootstrap';
import swal from 'sweetalert2';
window.Swal = swal;
